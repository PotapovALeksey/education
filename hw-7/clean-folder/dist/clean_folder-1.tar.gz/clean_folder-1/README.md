# Clean_folder

This project is usefull to sort files inside some directory 
[Clean_folder repository](https://github.com/PotapovALeksey/education/tree/main/hw-6/)